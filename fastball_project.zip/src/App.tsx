import BaseballGame from './components/BaseballGame'
import './App.css'

function App() {
  return (
    <div className="App">
      <BaseballGame />
    </div>
  )
}

export default App
